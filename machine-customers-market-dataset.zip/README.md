# Machine Customers Market Dataset

This repository contains a structured dataset representing the global **Machine Customers Market**.  
The dataset is inspired by publicly available information from NextMSC.

## Files Included
- `market_overview.csv` – Market size & CAGR by year  
- `segmentation.csv` – Segmentation breakdown  
- `metadata.json` – Dataset metadata  
- `README.md` – Documentation  

## Source  
https://www.nextmsc.com/report/machine-customers-market-3584
